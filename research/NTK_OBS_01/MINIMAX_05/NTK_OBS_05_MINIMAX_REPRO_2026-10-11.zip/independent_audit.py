#!/usr/bin/env python3
"""Second in-package checker. Does not import the main verifier.

Validates the published bracket certificates by direct rational inequalities,
independently computes the four family interval witnesses, and checks the
horizon/target optimality conditions. This is NOT external peer review.
"""
from fractions import Fraction as Q
from pathlib import Path
import json

C={
 'A':(Q(1,4),Q(1,2)),
 'B':(Q(3,52),Q(1,2)),
 'C':(Q(1,20),Q(275,108)),
 'D':(Q(1,10),Q(5,2)),
}
D=Q(1,1000); NOISE=Q(1,100)
a=Q(89,100);b=Q(91,100)


def difference(t,span):
    if t==0:return Q(0)
    return (a+span)**t-a**t


def main():
    data=json.loads(Path(__file__).with_name('results.json').read_text(encoding='utf8'))
    assert data['date']=='2026-10-11' and data['project']=='NTK-OBS-05'
    for label,(q,w) in C.items():
        row=data['box_result']['families'][label]
        assert Q(row['full_parameter_linf_minimax_exact'])==D
        assert Q(row['nodes_only_linf_minimax_exact'])==D
        assert Q(row['weight_shift_all_time_upper'])==D
        assert Q(row['node_shift_all_time_upper'])==w*D/(1-q-D)<NOISE
        # Verified rational inequality valid for all t >= 1:
        # t*z^(t-1) <= 1/(1-z) when z in [0,1), as geometric terms dominate.
        assert q+D<1 and 0<D<NOISE
    # Even if every nonnegative integer is queried, two opposite w0 and q0
    # endpoint parameter shifts share the same *full* centered transcript.
    assert (Q(12,11)*b)<1  # All t>=12 are dominated by time 11 for any pair.
    eps_cases=data['slow_slice']['noise_cases']
    numrows=0; targetchecks=0; tested_exact_single_times=0
    for noise_key,case in eps_cases.items():
        e=Q(noise_key)
        rows=case['horizons']
        assert len(rows)==25
        for h,row in enumerate(rows):
            numrows+=1
            assert row['horizon']==h
            diameter_lo=Q(row['minimax_diameter_lower'])
            diameter_hi=Q(row['minimax_diameter_upper'])
            assert Q(0)<=diameter_lo<=diameter_hi<=b-a
            assert Q(row['minimax_risk_lower'])==diameter_lo/2
            assert Q(row['minimax_risk_upper'])==diameter_hi/2
            # An adversary can make a and a+diameter_lo have a common
            # transcript at *every* queried time <=h.
            assert all(difference(t,diameter_lo)<=2*e for t in range(h+1))
            if row['exact_prior_saturation']:
                assert diameter_lo==diameter_hi==b-a
                assert row['best_single_time'] is None
            else:
                assert diameter_hi-diameter_lo==Q(1,10**12)
                # Upper diameter is impossible for any common transcript:
                # at least one time separates by more than 2e.
                separators=[t for t in range(1,h+1) if difference(t,diameter_hi)>2*e]
                assert separators
                chosen=row['best_single_time']
                assert chosen in separators
                assert difference(chosen,diameter_lo)<=2*e
                tested_exact_single_times+=1
                if row['unique_best_time_certified']:
                    for t in range(1,h+1):
                        if t!=chosen:
                            # All other single-query optimality thresholds are
                            # to the right of the chosen upper rational bound.
                            assert difference(t,diameter_hi)<=2*e
        # For each noise level, full arbitrary horizon and horizon 11 coincide.
        key=lambda h:(rows[h]['minimax_risk_lower'],rows[h]['minimax_risk_upper'])
        assert all(key(h)==key(11) for h in range(11,25))
        assert [Q(x) for x in case['all_time_minimax_risk_certified_interval']]==[
            Q(rows[11]['minimax_risk_lower']),Q(rows[11]['minimax_risk_upper'])]
        for item in case['target_costs']:
            targetchecks+=1
            tau=Q(item['target'])
            assert 0<tau<(b-a)/2
            d=2*tau
            times=[k for k in range(1,12) if difference(k,d)>=2*e]
            if times:
                assert item['status']=='ONE_QUERY_MINIMAX_COST'
                assert item['first_time']==min(times)
                assert Q(item['cost'])==Q(1)+Q(item['first_time'],4)
                assert all(difference(k,d)<2*e for k in range(1,item['first_time']))
            else:
                assert item['status']=='IMPOSSIBLE_AT_ANY_INTEGER_HORIZON'
                assert item['first_time'] is None
    # Distinct noise levels genuinely change which instant is best.
    assert eps_cases['19/500']['time_at_h11']==10
    assert eps_cases['1/100']['time_at_h11']==9
    assert eps_cases['1/25']['time_at_h11'] is None
    print('PASS independent rational bracket check:',numrows,'horizon/noise configurations')
    print('PASS all four box full-parameter and node-only all-time minimax lower witnesses')
    print('PASS',targetchecks,'precision/cost tests and',tested_exact_single_times,'positive single-time certificates')
    print('PASS exact time-choice transition t=9 to t=10; all later times dominated')


if __name__=='__main__':main()
