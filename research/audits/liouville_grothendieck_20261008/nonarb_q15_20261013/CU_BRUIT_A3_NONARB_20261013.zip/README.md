# CU-BRUIT-02 — A3-NONARB — second analytic interval engine (13 October 2026)

**Research status: independent of FLINT/Arb, conditional on mpmath.iv elementary interval semantics and a written Euler–Maclaurin/Cauchy bound. NOT an independently refereed theorem or a global certification.** The library itself describes interval functionality as experimental. No GRH or LI proof, no certified prime-race probability, no publication claim.

## Result from six contours

| Conrey primitive character | Large rectangle winding | Small rectangle winding | Positive-height zeros below 25 |
|---|---:|---:|---:|
| 15.2 (even, complex) | 13 | 1 | **12** |
| 15.14 (odd, real) | 13 | 0 | **13** |
| 15.8 (even, complex) | 13 | 1 | **12** |
| **Sum** | **39** | **2** | **37** |

The large rectangle is the positively oriented boundary of `[-1/8, 9/8] + i[-1/2,25]`. The small rectangle has the same real limits, and imaginary limits `[-1/2,1/2]`. The small rectangle contains the known trivial zero `s=0` of the two even characters, but not of the odd character (whose `L(0)=2`). The two winding numbers, together with holomorphy and nonzero boundaries, eliminate this central zero and count the zeros in `0<Im(s)<25`. No assertion is made at arbitrary height or for other conductors.

The 39 partition files contain **791** whole-arc image boxes (244 for 15.2, 306 for 15.14, 241 for 15.8, across both contours). Each box excludes the complex origin; the fractions-only verifier checks exact coverage, consecutive intersections, positive contour orientation and the winding of a homotopic rational polygon.

## Analytical method — no Arb, no FLINT or Gamma

For a primitive nonprincipal character modulo 15:

`L(s,chi) = 15^(-s) sum_{a in U(15)} chi(a) zeta(s,a/15)`.

Using Euler–Maclaurin at `N=20`, with `P=28` corrections, each Hurwitz tail is approximated by

`zeta(s,a) = sum_{n=0}^{N-1} (n+a)^(-s) + (N+a)^(1-s)/(s-1) + (N+a)^(-s)/2 + sum_{k=1}^{P} [B_(2k)/(2k)!] (s)_(2k-1) (N+a)^(-s-2k+1) + R_P(s,a)`.

The pole term is analytically cancelled across the eight characters using `sum chi(a)=0`: writing `w=s-1`, `h_a=log(1+a/(15N))`, and `exprel(z)=(exp(z)-1)/z`,

`sum_a chi(a) (N+a/15)^(-w)/w = -N^(-w) sum_a chi(a) h_a exprel(-w h_a)`.

`exprel` is evaluated as the first 50 terms of its entire Taylor series, with an explicit remainder bound. Other terms are regrouped by the character-zero-sum identity *before* interval evaluation to reduce dependency overestimation. There is no Gamma factor, Hardy Z call, Dirichlet L library routine or use of FLINT.

For `-1/8 <= Re(s) <= 9/8` and `-1/2 <= Im(s) <= 25`, the Euler–Maclaurin remainder bound, after summing all eight residues and the conductor factor, is exactly conservatively bounded by

`E_EM <= 64 * product_{j=0}^{2P-1}(j+27) * N^(2-2P) / [6^(2P) * (2P-2)]`,

with `P=28`, `N=20`. The `exprel` truncation contribution is bounded by `128*N*2^50/51!`. The combined error is below `2.057e-18`. This follows from the Bernoulli Fourier bound `|B_(2P)(x)| <= 2(2P)! zeta(2P)/(2*pi)^(2P)`, `zeta(2P)<2`, `pi>3`, and `|s+j|<j+27` on the declared region. These are deliberately conservative inequalities.

For more efficient enclosure of difficult contour segments, a Taylor model at each rational segment midpoint is used:

`L(z) = L(c) + L'(c)(z-c) + (z-c)^2 * integral_0^1 (1-t) L''(c+t(z-c)) dt`.

The finite Euler–Maclaurin expression is differentiated by a *separately implemented*, second-order forward automatic differentiation (`J2`). On a `1/10`-complex neighborhood of the six contour boundaries, the same analytic remainder is below `1e-14`; Cauchy's estimates thus permit additional `1e-13` and `2e-12` componentwise derivative-error radii. This gives a first-order centered enclosure plus second-order correction. Whenever a whole-segment box cannot exclude zero, it is split; unresolved segments cause failure.

**Trust boundary:** the mathematical remainder arguments must be checked independently. `mpmath.iv` 1.3.0 is different from Arb but remains an experimental interval engine; its correct containment for the *elementary* real logarithm, complex exponential and arithmetic calls used here is assumed, not formalized. The fractions-only replay **does not certify the truth of those analytic source boxes**, only their exact topology assuming valid enclosures.

## Reproduction

Local Python generation (internet/package installation may be required):

```
python -m pip install 'mpmath==1.3.0'
python worker.py --b 1 --top 25 --side 0 --out parts/b1_large_s0.json
```

For a large contour, use four sides. The long vertical left side has 102 base segments and was generated in slices `[0,20)`, `[20,40)`, `[40,60)`, `[60,80)`, `[80,100)`, `[100,102)`; other sides were run in one piece. The small contour uses the same sides at `--top 1/2` (without slicing). The complete inputs/replay receipts are already included in this archive.

For **independent exact-rational replay with only Python's standard library**:

```
python -S replay_offline.py
python -S test_offline.py
```

For checks of the interval formulas (requires mpmath):

```
python test_analytic.py
```

Six negative integrity tests and four formula/regression tests passed on 13 October 2026. The six-contour exact replay passed after verifying all 39 files; the counts shown above are precisely the output of that replay. No use is made of L-zero seeds to compute the contour winding.

## Boundaries for the program

- The original 37 external decimal matches with Aveiro remain a **distinct** evidence layer.
- The earlier FLINT/Arb completed-L finite certificate and this Hurwitz/interval approach produce the same 12/13/12 counts using different evaluation and winding algorithms, but neither has undergone independent human mathematical review.
- GRH, LI, the prime-race limit law, its tail and the modeled probability `~0.2894` remain open and **not certified**.
- Conductor-3/5 existing zero ordinates were not recertified here.
- The PR must remain a draft; no merge, external submission, release, DOI or priority claim follows from these calculations.

References: https://mpmath.org/doc/current/contexts.html ; https://pmc.ncbi.nlm.nih.gov/articles/PMC5549576/ ; https://github.com/alexcour/couret-finite-verifications/pull/28 .
